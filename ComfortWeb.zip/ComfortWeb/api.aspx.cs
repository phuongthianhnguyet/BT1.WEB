﻿
using System;
using System.Web;
using System.Web.UI;

namespace ComfortWeb
{
    public partial class api : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Không làm gì khi load lần đầu
                return;
            }

            // Lấy dữ liệu từ request POST
            string name = Request.Form["name"];
            string mood = Request.Form["mood"];

            // Tạo thông điệp an ủi
            string message = $"Chào {name}! Mình biết bạn đang cảm thấy '{mood}'. Mọi chuyện sẽ ổn thôi, hãy mỉm cười nhé!";

            // Trả về JSON
            Response.Clear();
            Response.ContentType = "application/json";
            Response.Write("{\"message\":\"" + message.Replace("\"", "\\\"") + "\"}");
            Response.End();
        }
    }
}
