﻿

using System;
using ComfortLib;

namespace ComfortConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("===  An Ủi Người Cô Đơn ===");

            Console.Write("Nhập tên của bạn: ");
            string name = Console.ReadLine();

            Console.Write("Nhập cảm xúc hiện tại (buồn/cô đơn/stress/...): ");
            string mood = Console.ReadLine();

            Comfort c = new Comfort();
            c.Name = name;
            c.Mood = mood;

            string message = c.GetMessage();

            Console.WriteLine("\n>>> Lời an ủi dành cho bạn:");
            Console.WriteLine(message);

            Console.WriteLine("\nNhấn Enter để thoát...");
            Console.ReadLine();
        }
    }
}
