﻿using System;

namespace ComfortLib
{
    public class Comfort
    {
        private string name;
        private string mood;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Mood
        {
            get { return mood; }
            set { mood = value; }
        }

        public string GetMessage()
        {
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(mood))
                return "Bạn chưa nhập đủ thông tin.";

            string message = "";

            switch (mood.ToLower())
            {
                case "buồn":
                    message = "Này " + name + ", đừng buồn nữa nhé 🌸. Mọi chuyện sẽ ổn thôi!";
                    break;
                case "cô đơn":
                    message = name + ", bạn không hề một mình đâu 🤗. Luôn có người quan tâm đến bạn!";
                    break;
                case "stress":
                    message = name + ", thở sâu nào 🍀. Cho bản thân nghỉ ngơi chút, bạn xứng đáng được thư giãn.";
                    break;
                default:
                    message = name + ", mình chúc bạn một ngày thật vui vẻ 😊!";
                    break;
            }

            return message;
        }
    }
}
